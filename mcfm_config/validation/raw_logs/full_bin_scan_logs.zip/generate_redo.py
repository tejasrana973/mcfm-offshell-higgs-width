# generate_redo.py
import re

redo = {
    "128": ["01", "04", "05"],
    "129": ["10"],
    "131": ["04", "08", "10", "11"],
    "132": ["01", "05"],
}
for proc, bins in redo.items():
    for b in bins:
        with open(f"input_p{proc}_bin{b}.ini") as f:
            text = f.read()
        text = re.sub(r"(?m)^(\s*runstring\s*=).*", rf"\1 p{proc}_bin{b}c", text)
        text = re.sub(r"(?m)^(\s*precisiongoal\s*=).*", r"\1 0.03", text)
        with open(f"input_p{proc}_bin{b}c.ini", "w") as f:
            f.write(text)
        print("wrote", f"input_p{proc}_bin{b}c.ini")